import { Component } from '@angular/core';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent {



  links = [
    { label: 'Home', path: '/home.component.ts' },
    { label: 'About Us', path: '/app.component.html' },
    { label: 'SIGN UP', path: '/app.component.html' }
  ];
}
