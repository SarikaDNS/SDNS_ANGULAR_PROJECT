import { Directive,ElementRef,HostListener } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {

  constructor(private el : ElementRef) {
    this.el.nativeElement.style.backgroundColor="orange";
   }
   @HostListener('Mouseenter') onMouseenter(){
       this.highlight('green')
   }
   @HostListener('Mouseleave') omMouseleave(){
        this.highlight('light-white')
   }

   @HostListener('click') onClick(){
    this.highlight('purple');
  }


   private highlight(color:string){
    this.el.nativeElement.style.backgroundColor=color;
   }

}
