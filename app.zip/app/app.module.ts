import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductInfoComponent } from './product-Info/product-info.component';
import { FooterComponent } from './footer/footer.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SlideComponent } from './slide/slide.component';
import { CartComponent } from './cart/cart.component';
import { StarComponent } from './star/star.component';
import { HomeComponent } from './home/home.component';
import { NavigationComponent } from './navigation/navigation.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConvertPipe } from './convert.pipe';
import { HighlightDirective } from './highlight.directive';
import { SignupComponent } from './signup/signup.component';
import {HttpClientModule} from '@angular/common/http';


const routes : Routes=[




]


@NgModule({
  declarations: [
    AppComponent,
    ProductInfoComponent,
    FooterComponent,
    SlideComponent,
    CartComponent,
    StarComponent,
    HomeComponent,
    NavigationComponent,
    ConvertPipe,
    HighlightDirective,
    SignupComponent,
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NoopAnimationsModule,
    RouterModule,
    HttpClientModule,

    //RouterModule.forRoot(routes)

  ],
  providers: [],
  bootstrap: [AppComponent],
  exports:[],

})


export class AppModule { }
