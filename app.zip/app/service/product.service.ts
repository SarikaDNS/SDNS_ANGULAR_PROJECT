import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject, Subscription, delay, filter, interval, map, of, pipe } from 'rxjs';
import {HttpClient} from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class ProductService {

  value$= of(1,2,3,'hello',[1,2,3]);

   sub$ !: Subscription;
   private cartcount =0;
   subject$ = new Subject<number>();//create a subj
   cartcount$ = new BehaviorSubject<number>(0);

constructor(private http : HttpClient) {


 }

 increment():void{
   this.cartcount += 1;
   console.log(this.cartcount);
   this.cartcount$.next(this.cartcount);
 }
}
