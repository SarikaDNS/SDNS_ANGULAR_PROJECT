import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {

  contacts = [
    {
      title: 'Here is our Website:',
      text: 'Just Click to visit ',
      link: 'https://himalayawellness.in/'
    },
    {
      title: 'Email Us: contactus@himalayawellness.com',
      text: 'you will get response from Mon-Sat only ',
      link: ''
    },
    {
      title: 'Call Us: 1–800–208–1930',
      text: 'Mon-Fri: 9:00am - 5:00pm',
      link: ''
    },
    {
      title: 'WhatsApp Us: 89518 91930',
      text: 'we can help 24*7 ',
      link: '#'
    }
  ];
}
