import { Component, OnInit } from '@angular/core';
import { ProductService } from '../service/product.service';

@Component({
  selector: 'app-product-info',
  templateUrl: './product-info.component.html',
  styleUrls: ['./product-info.component.scss']
})
export class ProductInfoComponent {
  imgStyle={
    'height.px':250,
    'width.px' :300,
  }
  products=[
      {
        id:1,
        name:'Neem FaceWash',
        image:'/assets/NeemFaceWash.jpg',
        price:260.00,
        code:'H-01',
        rating:5,
        description:'Clinically Proven Pimple-free Healthy Skin Expert'
      },
      {
        id:2,
        name:'Natural Glow Rose FaceWash',
        image:'/assets/NaturalGlowRose.jpeg',
        price:245.00,
        code:'H-02',
        rating:4,
       description:'The goodness of Rose to reveal your natural glow'
      },
      {
        id:3,
        name:'Anti-HairLoss Cream',
        image:'/assets/AntiHairLossCream.jpg',
        price:160.00,
        code:'H-03',
        rating:4.5,
       description:'The only side-effect is hair growth'
      },
      {
        id:4,
        name:'Bath Soap',
        image:'/assets/Soap.jpg',
        price:60.00,
        code:'H-04',
        rating:3.4,
       description:'Cleanses and purifies skin'
      },
      {
        id:5,
        name:'Cleansing_Toning',
        image:'/assets/Cleansing_Toning.jpg',
        price:340.00,
        code:'H-05',
        rating:5,
       description:'Deep Cleanses, Clarifies and Refreshes'
      },
      {
        id:6,
        name:'Heena',
        image:'/assets/natural-shine-henna.jpg',
        price:75.00,
        code:'H-06',
        rating:4  ,
       description:'Soft, Shiny, and Healthy Hair'
      }
      ];





  filter='';
  ps: any;
  addtocart(pro:any){
    //console.log(pro);
    this.ps.increment();
  }
  onRatingClicked():void{
    alert('You have Clicked');
  }
//other code


}
